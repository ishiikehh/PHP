<?php
/**
 * Created by PhpStorm.
 * User: TAKE PRODUÇOES
 * Date: 19/05/2015
 * Time: 15:58
 */
$ss = Date("Y");
date_default_timezone_set('America/Sao_Paulo');
$data = date('d/m/Y');
$hora = date('H');

if($hora > "6" && $hora < "12"){
    $helo = "Bom Dia";
}
elseif($hora = "12" && $hora < "18"){
    $helo = "Boa Tarde";
}else{
    $helo = "Boa Noite";}
    ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Paradox Love | Cap #2</title>
    <meta charset="UTF-8"/>
    <link href="estilo.css" rel="stylesheet"/>
    <link href="estilokenichi.css" rel="stylesheet"/>
</head>
<body bgcolor="#f0ffff">
<div id="main"><figure id="logo">
        <img src="http://ookamienterprise.esy.es/logo.png">
    </figure>
    <h1>Ookami Enterprise | Cap #2</h1>
</div>

<div id="pages">
    <h2>Paradox Love</h2>
    <h4>Capítulo 2 – A marca que a deixa inquieta.</h4>
<h5>
    Indo para a sala do clube sentia ódio de mim mesmo e começava a murmurar por ter perdido aquela oportunidade, mas eu não podia aceitar a amizade dela, ela poderia interpretar mal minhas reais intenções e me colocar na zona da amizade e não era isso que eu queria. Quase chegando a sala Genji me encontra.<br/>
    - Kaito, bom dia! O que aconteceu ontem? Te liguei várias vezes e você não me atendeu.<br/>
    Nesse instante respirem bastante pra ficar calmo. E tomei minha decisão.<br/>
    - Bom dia Genji-kun! - "kun"? Tem muito tempo que você não usa esse sufixo (risos). O que aconteceu?  - Me acompanhe até a sala do clube, temos que conversar. - Tudo bem.<br/>
    *na sala*<br/>
    - O que foi? - Me explica o que foi aquilo ontem? A garota se confessando e logo em seguida você pisa nela como se fosse uma latinha de refrigerante? - Era sobre isso que eu ia te falar ontem, mas você não me atendeu.  - Precisava falar daquele jeito com ela?  - Como assim? Só fui sincero! E além do mais você gosta dela não é? Eu tinha que acabar com qualquer sentimento que ela tivesse por mim. Fiz aquilo por você. - Só um “não” já era o suficiente... Ei desde quando você sabia que eu gostava dela? - Desde o ano passado você fitava o olho nela durante a Ed. Física. E também como você não me atendia liguei pro seu irmão e ele me confirmou. Sinto muito Kaito, não sabia que ela gostava de mim.  - Tudo bem, mas você vai ter de pedir desculpas pra ela. - Por quê?  - O motivo é óbvio.  Você foi grosseiro com ela sem necessidade, afinal garotas são mais sensíveis. - Está, Tá... - Ainda hoje, no intervalo. - O quê?  - Sim, isso mesmo. Sem conversa.  - Poxa, tudo bem. Só por você.<br/>


    - E também vai pagar meu almoço. - O quê? Aí já é abuso. - Sem conversa, afinal você querendo ou não roubou minha garota.  -Aah... Está bom.
    Enquanto terminávamos de falar sobre aquele assunto nos encontramos no corredor da escolar justamente com a Inaho-san e suas amigas. Quando ela nos viu sua reação não foi das melhores, pois enquanto para nós já estava tudo resolvido para ela eu nem me considerava mais amigo do Genji. Ao olhar nos olhos dela vi um sentimento de raiva enorme crescendo, nesse instante sua reação foi sair correndo dali. Eu fui tentar consertar a situação correndo atrás dela para explicar. O terraço foi o refúgio dela naquele momento. Chegando ao terraço tentei explicar a situação:<br/>
    - Inaho-san, por favor, me escute. - Não me chame pelo primeiro nome <sup>2</sup>. - Perdão! Tachibana-san, por favor, <br/>
deixe-me explicar o que está acontecendo. - O que você tem a dizer? Não disse que não iria mais falar com o Sakamotokun? Você está brincando comigo por acaso? - Me deixe explicar primeiro!<br/>
    *Genji chega ao terraço*<br/>
    - Me deixe explicar tudo! - Espera Genji, fica quieto! (gritando com ele) - Me dê licença jovem apaixonado, você não vai saber medir suas palavras. - Mas... - Deixe comigo. É o seguinte Tachibana-san eu te rejeitei por que ele aqui (aponta pra mim) gosta de você. Eu pensei em tudo ontem. Nós dois não combinamos, mas aquele jovem rapaz (aponta de novo) foi feito pra você, um casal feito sob medida. Chegar ser nojento o quanto vocês combinam e ainda mais... (Interrompido) - Já chega disso! (Inaho brada com raiva) Vocês estavam brincando com meus sentimentos? É isso que estavam fazendo? Me fazendo de boba ou coisa parecida? Sakamoto-kun eu realmente gostava de você, mas agora vejo o quanto você é sujo e podre. E você Takeyama-kun(olhando enfurecida)  <br/> </h5><fieldset><a id="asteristico"> 2 Nota ao leitor: No Japão chamar alguém pelo primeiro nome é considerado uma forma íntima de se tratar, geralmente utilizado pelos pais ou pessoas muito próximas. De forma respeitosa a pessoa sempre é chamada pelo sobrenome. Exemplo: Inaho é o primeiro nome e Tachibana o sobrenome. É como se ela dissesse: “Me respeita que eu não sou tuas nega”.</a></fieldset><h5> </h5><div id="pagenum">Capítulo 2 – A marca que a deixa inquieta. | 6 |</div> </div><div id="pages"><h5>armando um circo pra tentar me conquistar enquanto estava abalada. Era esse o seu jogo? Pois saiba que quase deu certo. Ontem você quase me fez te ver de outra maneira, mas ainda bem que percebi o quanto você é imaturo. <br/>
    Não podia deixar aquilo acontecer. Eu não estava só voltando à estaca zero, na verdade eu estava indo a níveis negativos. Não vi escolha a não ser me defender. <br/>
    - Agora é a minha vez de falar Genji! Tachibana-san não é isso... *TAPA NA CARA* - Não chegue perto de mim! Já fui magoada demais em menos de um dia. Por favor, se afastem de mim. <br/>
    Ela corre em direção à saída do terraço e desce as escadas. Depois do tapa fiquei paralisado pela reação dela, mas decidi não ir atrás dela naquele momento. Qualquer coisa que eu fizesse só pioraria a situação. Respirei fundo enquanto o Genji tentava se desculpar. <br/>
    - Kaito me desculpe eu não sabia que a situação ia chegar a esse ponto, por favor, amigo me perdoe. Pensei que a reação dela teria sido diferente, eu estou tão surpreso quanto você. - Tudo bem, eu cheguei a imaginar que uma situação como esse viria de você. A intenção foi boa, mas a execução me rendeu esse vermelho no rosto.<br/> - Como estou arrependido. AAAAAHHH (grito) devia ter ficado quieto! <br/>- Esqueça, vamos pra sala. <br/>
    Descemos as escadas e fomos para a sala de aula e ao entrar na sala não encontrei a Inaho. Fiquei preocupado, por que ela tinha ficado muito abalada com o que tinha acontecido. Fui perguntar para as amigas dela onde ela estava. <br/>
    - Onde está a Tachibana-san? * olham desconfiadas*<br/> - Você não precisa saber onde ela está só precisa saber que está longe de você. Que tipo de monstro você e o Sakamoto-kun são? Como ousa brincar com os sentimentos da Inaho-san? Se afaste dela Takeyama-kun só faça isso. <br/>- Ela entendeu tudo errado, nem sequer tive o tempo de explicar o que tinha acontecido. Só fale a ela que peço as mais sinceras desculpas e que foi um mal entendido. <br/>


    O professor entra na sala e eu volto pro meu lugar. Aula de japonês moderno. Eu até gosto da disciplina, mas depois do tumulto de hoje mais cedo não estava com muita vontade de assistir a aula. O professor enquanto dava a aula notou minha desatenção e me chamou. Ao voltar minha atenção para o professor ele viu meu rosto ainda vermelho por causa do tapa que tinha levado. Ele então me convence a ir à enfermaria para tratar da marca feita então me levantei e fui à enfermaria. Chegando lá a enfermeira me tratou e me pediu para contar o que tinha acontecido. Só fiz um breve resumo. <br/>
    - Foi só um mal entendido e uma confusão. Talvez eu até merecesse esse tapa, mas eu queria que a pessoa ao menos tivesse me escutado. <br/>
    Depois de tratado voltei à sala com uma bandagem no rosto. Eu parecia ter apanhado de um bando de valentões por causa de todos os curativos que tinha. Mas a cena da enfermaria não acaba com minha saída, mas como não sei o que aconteceu lá vou passar a palavra para a pessoa que passou por tudo aquilo. <br/></h5><div id="pagenum">Capítulo 2 – A marca que a deixa inquieta. | 7 |</div> </div><div id="pages"><h5>
    – Visão da Inaho – <br/>
    Meu nome é Tachibana Inaho e estou no segundo ano do colegial. Assim como qualquer garota normal eu também tenho uma paixão colegial. O garoto por quem sou apaixonada se chama Sakamoto Genji, ele está na mesma turma que eu e jogador do time de futebol da escola. Ele é bem popular entre as garotas, então é normal que eu tenha rivais por causa dele, mas se eu for rápida eu posso fazer ele me notar. Só preciso aproveitar o momento certo e ser bem discreta quanto a esse assunto. Semanas após o início das aulas decidi me confessar meu amor para o Sakamotokun, mas ele sempre estava com o melhor amigo dele, Takeyama Kaito, capitão do time de futebol. Depois do fim das aulas esperei até o fim do treino do time de futebol e até o momento em que ele estivesse sozinho. E não demorou muito até esse momento chegar. Quando ele se separou do grupo o chamei fora do campo. <br/>
    - Sakamoto-kun venha aqui, por favor! <br/>- Oh Tachibana-san o que foi? <br/>- Posso conversar com você? Serei rápida e sei que você está cansado. <br/>- Tudo bem. Vamos beber algo estou morrendo de sede. <br/>
    *No pátio perto das máquinas de bebida* <br/>
    - Pois então o que queria me falar? <br/>


    - Sakamoto-kun é... (pausa, fica corada e respira fundo) Eu gosto de você, por favor, seja meu namorado! - (surpreso) Wow! Que situação repentina. Mas não posso aceitar você como minha namorada, você não faz meu tipo. Baixinha demais e muito desajeitada. Não vejo muita vantagem em namorar uma garota como você, talvez eu estivesse perdendo meu tempo contigo, afinal existem garotas mais bonitas. Sinto muito, mas não. <br/>
    Após terminar de falar eu me desliguei totalmente. Enquanto ele saía, eu me postava de joelhos no chão e não sei quanto tempo se passou enquanto estava naquele estado. Aquele cretino quebrou meu coração, por dentro eu estava endurecida pelo ódio. Mas com o passar do tempo uma sombra estava perto de mim. Não fazia ideia do que o quem podia ser, mas não me importava.  Com o passar do tempo voltei a mim e me deparei com Takeyama Kaito, melhor amigo do miserável que tinha me humilhado. Eu não fazia ideia do que ele estava fazendo ali, mas só sei que ele ficou todo o tempo me esperando. Qual era a intenção dele? Zombar de mim? O que de pior poderia acontecer? Voltei pra casa em companhia dele e aparentemente suas intenções não eram as piores, ele conseguiu até tirar um sorriso de mim naquela situação, mas de repente tudo começou a rodar e fiquei muito assustada. Quando me acalmei percebi o que tinha acontecido. Quase fui atropelada. Talvez eu realmente seja desastrada como o Sakamotokun disse, mas isso não importa, pois enquanto eu estava acompanhada por aquele garoto eu me sentia mais calma e segura, porém não queria que ele soubesse disso.  Tentei ser rude com ele para não frustrá-lo depois, mas ele parecia ser muito forte e não ligava pra minhas palavras rudes. Ele disse que aquele comportamento do amigo dele não era normal e que deixaria de conversar com </h5><div id="pagenum">Capítulo 2 – A marca que a deixa inquieta. | 8 |</div> </div><div id="pages"><h5>ele. Talvez ele seja confiável. Não queria que ninguém soubesse do que tinha acontecido naquele dia, mas ele presenciou tudo e prometeu não espalhar pra ninguém da escola. Seria estranho andar com ele, mas depois me senti bem ao lado dele. Quem sabe ele mereça meu respeito. No dia seguinte eu o encontrei no mesmo ponto, mas ele me ignorou totalmente. Ele estava cumprindo a nossa promessa, mas quem sabe eu pudesse mudar aquela situação. O chamei pra conversar e lhe propus uma amizade, mas de novo fui rejeitada. O que está acontecendo comigo? Sou tão repugnante assim? Ele me pediu paciência e falou que isso não daria e que me explicaria com o tempo. Não entendo esses homens de hoje. Então o deixei de lado naquele momento e fui para a sala de aula, pouco tempo depois ele aparece com o cara que seria seu ex-amigo, mas que na verdade aparentava estar tudo bem, como se nada tivesse mudado. Eles só podiam estar brincando comigo! Eu não podia ficar ali vendo aquilo e então saí correndo e fui em direção ao terraço.  Takeyama-kun me alcançou e tentou me acalmar querendo explicar, mas depois que o Sakamoto-kun chegou e começou a explicar tudo foi aí que entendi o que estava

    acontecendo. Tudo já estava armado para mim, uma brincadeira de mau gosto. Enquanto o Sakamoto me humilhava o Takeyama se aproveitava de minha fragilidade, tentando me pegar desprevenida. Aqueles dois eram típicos vilões de história em quadrinhos e eu quase fui vítima deles. Por um deslize eu teria caído na brincadeira. Quando o Takeyama-kun se aproximou eu o afastei dando um tapa nele e então saí do terraço e fui correndo para as minhas amigas. Não estava em condições de assistir as primeiras aulas e fui para a enfermaria. Lá a enfermeira me pediu para descansar em um dos leitos e fechou as cortinas que a cobrem. Pouco tempo depois alguém entra na enfermaria, era o Takeyama-kun. O professor o tinha mandado para tratar da marca do tapa que parecia ter deixado todo o lado do rosto inchado (bem feito). Enquanto a enfermeira o ajudava eu escutava a conversa entre eles e eu acho que devia tê-lo escutado. Quando ele saiu Nogai-sensei (a enfermeira) me perguntou: - Foi esse o rapaz em quem você bateu? - Sim. - O que ele lhe fez pra você ter batido nele? - (assustada me levantei do leito) Ficou muito inchado? - Um pouco, mas logo ele estará melhor. Ele parece ter um psicológico forte. - Que bom... Espera... Deixa.  - Ele é seu namorado? - Não, mas ele me prometeu algo e não cumpriu. - Mas você o deixou explicar? - (envergonhada) Não. - Você tem provas concretas de que ele não é confiável? - Talvez - “Talvez” não é uma certeza. Escute-o e depois tire suas conclusões. Agora volte pra sala, você não pode ficar aqui o dia todo. - Tudo bem, muito obrigado Nogai-sensei! (me curvo e saio)
    Essa foi a visão da Tachibana Inaho até esse momento. Agora vamos voltar à visão de Takeyama Kaito a partir daquele mesmo momento. <br/>
    – Visão do Kaito – <br/>
    No horário de almoço peguei meu bentô <sup>3</sup> fui em direção a sala do clube. Quando apontava para a porta me deparei com Tachibana Inaho, ela era a última pessoa com

    quem eu queria me encontrar naquele momento. Ela estava parada em frente à porta e eu parado em sua frente. Ambos de cabeça baixa sem contato nenhum contato visual. Alguns de nossos colegas começaram a olhar para aquela cena. O que com certeza chamava muita atenção. Eu queria sair logo dali, pois o silêncio dela me causava um mal enorme. <br/></h5><fieldset>
    <a id="asteristico"> 3 Nota ao leitor: (Obento) ou (bentô) é o que nós conhecemos por marmita, mas como marmita é feio de falar vou deixar como bentô mesmo. É muito comum no Japão os alunos levarem seus lanches de casa o que é muito mais econômico para o bolso dos pais.</a></fieldset><div id="pagenum">Capítulo 2 – A marca que a deixa inquieta. | 9 |</div> </div><div id="pages"><h5>
    - Com licença, preciso passar (falei cabisbaixo e em tom baixo) <br/>
    Ela então deu passagem e saí daquela sala de tortura e fui para sala do clube de futebol. Ao chegar lá encontrei o Genji conversando com os outros membros do clube. Sentei e comecei a comer, mas parecia que a comida não tinha gosto. Genji sentou ao meu lado com seu bento e começou a conversar comigo. <br/>
    - Ainda desanimado? - Estou com uma cara tão ruim assim? - Você só brinca com a comida e mais nada. - Eu não queria que tivesse acabado daquele jeito. - Eu também estou muito arrependido, mas parece que quem levou os danos maiores foi você. - Um tapa na cara já conta bastante. - (...) Né. Acabe logo seu almoço que o treinador vai chegar daqui a pouco dar as instruções pro jogo de sexta. (se levanta e sai) - Pode deixar. (desanimado continuar a mexer no lanche) <br/>
    Enquanto eu terminava de comer o treinador Natsu chegou e parecia bem animado com um envelope em mãos. Aparentemente teríamos uma boa notícia.
    - Pessoal tenho em mãos as notícias animadoras. A primeira é que nossa inscrição para a Copa de Verão está feita! Se ficarmos entre os quatro melhores nossa vaga para o Campeonato Nacional está garantida! <br/>
    *Alunos se animam* <br/>
    - Mas calma, ainda tenho mais duas notícias. A segunda é que conseguimos mais um patrocinador e com isso os novos uniformes estão garantidos. E a terceira é que conseguimos marcar dois amistosos para os próximos dois finais de semana. São contra a escola Seiho e Mahou Tai. <br/>

    Desanimado eu escutava as notícias e instruções do Natsu-sensei. Com esse bombardeio de informações eu não conseguia pensar e processar tudo, mas eu sabia que com esses jogos e todas as preparações vindo eu teria de me preparar para ajudar o time.  Enquanto o treinador falava meu comportamento chamou sua atenção fazendo com que ele parasse de falar e falasse comigo. <br/>
    - O que está acontecendo Takeyama-kun? Você parece horrível com todas essas faixas. Deve ter sido por isso que a Nogai-sensei veio falar comigo mais cedo. - Não é nada demais, sensei. Foi só um arranhão e um... (pensei melhor e falar que levei um tapa não era boa ideia)... Uma bolada. Tudo normal. - Entendo. Então por hoje você está dispensando das atividades do clube. Amanhã eu preciso de você descansado para o começo do treinamento. - Mas sensei! –  - Não discuta comigo, afinal com essa cara você não irá produzir nada. Quando acabarem as aulas da tarde vá para casa descansar. - Tudo bem. Muito obrigado. <br/>
    Dispensado voltei para sala de aula e guardei meu bento na mochila. Ainda faltavam alguns minutos para o começo da próxima aula. Então um café não sairia mal, fui à máquina de bebidas4. Ao tirar minha lata de café fui sentar em um banco perto a máquina e desfrutar da minha bebida e observar o ambiente. Talvez eu melhorasse, mas de longe eu vi Tachibana-san vindo em minha direção. Por um instante eu fiquei nervoso e não fiz contato visual. Pelo visto mais alguém teve a ideia de molhar a garganta. Um suco de laranja caiu e ela começou a beber e ficou parada lá por um tempo degustando de seu suco. Sentado no banco eu só a observava, aparentemente eu não chamava a atenção dela.  O sinal estava por bater e eu já tinha terminado, mas aquele suco parecia infinito. Talvez ela estivesse chamando minha atenção, mesmo assim decidi por não mexer naquele assunto por enquanto. Segui em direção à máquina onde ela estava e a reação dela pareceu a de um susto discreto. Joguei minha latinha na lata de lixo metálico e fui embora.  Com o fim do intervalo voltei para a sala e ela também, porém mantinha uma distância considerável de mim. Suas amigas a encontraram no caminho para a classe e me olhavam com desprezo, preferi não dar atenção a alguns comentários feitos por elas. <br/>
    4Nota ao leitor: Em algumas escolas japonesas é comum ter máquinas de bebidas espalhadas pelos corredores, então não estranhe essa cena. E também é comum nessas ter café (Black Coffee) nas mesmas latinhas em que vemos refrigerantes. Geralmente essas máquinas são divididas em bebidas quentes e frias, ou seja, enquanto em uma você vê refrigerante e suco na outra você vê café e chás. <br/>

    Com o fim das aulas fui para o armário de sapatos5 me troquei e fui embora. Decidi pegar uma rota alternativa para minha casa pra evitar um possível encontro. Mesmo que eu pegasse um caminho mais longo eu acabaria passando pela rua da Tachibana-san. Tanto faz agora, o que eu quero é chegar em casa.   </h5><div id="pagenum">Capítulo 2 – A marca que a deixa inquieta. | 10 |</div>
    <fieldset id="nav" name="Navegação"><a href="cap1.php" id="nav"><- Cap #1</a> | <a href="cap3.php" id="nav">Cap #3 -></a> </fieldset>
</div>
<div id="footer">
    Ookami Enterprise <?php echo $ss; ?>
    <a href="http://nerdfakecompany.esy.es/nF_Studios/" id="logoInsider">Powered by nF Studios</a>
</div>
</body>
</html>