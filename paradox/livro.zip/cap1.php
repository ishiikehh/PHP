<?php
/**
 * Created by PhpStorm.
 * User: TAKE PRODUÇOES
 * Date: 19/05/2015
 * Time: 15:58
 */
$ss = Date("Y");
date_default_timezone_set('America/Sao_Paulo');
$data = date('d/m/Y');
$hora = date('H');

if($hora > "6" && $hora < "12"){
    $helo = "Bom Dia";
}
elseif($hora = "12" && $hora < "18"){
    $helo = "Boa Tarde";
}else{
    $helo = "Boa Noite";}
    ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Paradox Love | Cap #1</title>
    <meta charset="UTF-8"/>
    <link href="estilo.css" rel="stylesheet"/>
    <link href="estilokenichi.css" rel="stylesheet"/>
</head>
<body bgcolor="#f0ffff">
<div id="main"><figure id="logo">
        <img src="http://ookamienterprise.esy.es/logo.png">
    </figure>
    <h1>Ookami Enterprise | Cap #1</h1>
</div>

<div id="pages">
    <h2>Paradox Love</h2>
    <h4>Capítulo 1 – Rejeitado por quem amo.</h4>
<h5>
O sonho de todo adolescente colegial é arranjar uma paixão durante sua vida escolar. E eu como qualquer adolescente normal também tenho alguém de quem gosto. Sou Takeyama Kaito e estou no 2° ano, turma B e sou capitão do time de futebol da escola.  A garota de quem gosto esse ano está na minha turma. Seu nome é Tachibana Inaho. Ela é uma das alunas mais inteligentes do colégio, porém tem algumas características peculiares, por exemplo, seu comportamento desastrado, o sono durante algumas aulas, e seu pequeno círculo de amizades, come mais do que uma adolescente comum, mas por incrível que pareça ela é bem feminina.  Mas o que mais me chama atenção é o seu sorriso. Por que o sorriso dela me influencia tanto? Desde que a conheci sempre tentei conversar com ela, mas nunca consegui mais do que um “Bom dia”. Mas tanto faz, por que também fico sem palavras perto dela. Ela sempre foi sincera com todos Só a vi chorar uma vez e foi pela situação que menos imaginei: uma rejeição. Isso mesmo, ela foi rejeitada e eu infelizmente estava no local e acompanhei tudo. Foi o momento que mais me senti furioso e com raiva de mim mesmo. Ela foi rejeitada pelo meu melhor amigo, Sakamoto Genji. Ele simplesmente a humilhou Depois que ele saiu fiz o que achei certo naquele momento. Fui até ela e me sentei perto dela e fiquei em silêncio. Seus olhos estavam mortos e sem foco, me partia o coração vê-la daquele jeito e eu não sabia o quefazer, mas não podia falar "vai ficar tudo bem, existem caras melhores", eu não era próximo a ela. Então fiquei quieto ao seu lado até ela esboçar alguma reação e assim se passou uma hora. Quando ela. Voltou a si me perguntou:<br/>
- O que faz aqui? Já não deveria ter ido embora?  - Eu simplesmente não podia deixá-la nessa situação. Eu já estava indo embora quando vi o Genji e vim chamá-lo para ir junto e então acabei vendo tudo, sinto muito eu não sabia que ele era assim. Mas vamos embora, eu te acomp... - Eu posso ir só, não preciso de sua ajuda! -Tem certeza?  -Sim, tenho!(começa a chorar) - Mesmo assim vou com você. - Por quê? Já falei que não precisa! - Minha casa é na mesma direção. - (Silêncio de conformação) Então não converse comigo.<br/>

-Tudo bem. Então começamos a andar de volta para nossas casas. Ela mantinha o olhar triste e cabeça baixa enquanto eu ficava em silêncio e mantinha certa distância. Tentava falar algumas palavras, mas eu não sabia colocá-las na forma correta. A atitude que o Genji tomou me deixou furioso tanto que eu nem o considerava mais meu amigo. A única coisa que podia fazer era esperar o amanhã. Enquanto caminhávamos, ela parou encolheu os ombros e berrou:<br/>
- Por que tudo isso está acontecendo comigo? O que eu fiz de errado? E por que raios você está me seguindo? - Ei eiei!! Eu já disse que minha casa é por aqui!  - Tanto faz! Por que não vai embora? - Eu bem que queria, mas eu ficaria mal deixando você nesse estado. Por favor, aceite isso (tira um lenço da mochila), seque suas lágrimas.  - (...) * surpresa* - Vamos, aceite, por favor, seque essas lágrimas. O lenço está limpo.
Ela pega o lenço meio desconfiada e seca as lágrimas<br/>
- Viu não te fez mal algum. - Obrigada (falando baixo) - Ham? Quê? - Já disse! - (risos) - Tudo bem. Vamos pra casa. - Não fique se achando por isso e sequer mencione o que aconteceu hoje na escola. - Não se preocupe, esse será nosso segredo. - Certo, certo.</h5><div id="pagenum">Capítulo 1 – Rejeitado por quem amo. | 1 |</div> </div><div id="pages"><h5>
Quando ela voltou a olhar para frente percebi um leve sorriso no seu rosto e então não me contive e abri um sorriso enorme por tê-la feito sorrir mesmo que um pouco. Mas aquele sorriso em meu rosto não durou muito tempo. Ela não havia prestado atenção no semáforo que estava fechado para pedestres. Quando a vi pôr o pé na faixa uma van vinha em sua direção. Eu não podia deixar algo acontecer a ela depois de conseguir tirar um leve sorriso do seu rosto. Aquele sorriso descontraído e sincero. A garota que eu amava A adrenalina do meu corpo foi a mil em um instante. Graças ao clube de futebol eu estava com um bom físico. Corri em sua direção em uma situação de tudo ou nada. A van estava em cima e meu tempo era curto, porém minha motivação era mais forte do que minhas limitações. Ela ainda não tinha visto a van quando pôs o pé na faixa e foi nesse momento em que a agarrei. Enquanto a segurava a abracei e rolamos pelo chão deixando o perigo maior passar. Acabei machucando meu braço, mas ainda não havia acabado. Outro carro vinha na segunda faixa. Nesse momento não sei de onde tirei forças, mas consegui desviar. Os carros pararam e o pior já tinha passado. Logo voltei ao meu estado normal e imediatamente fui ver como Inaho estava.  Enquanto eu a segurava esperava sua reação. Ela estava quieta, mas estava claro o quanto ela estava assustada. Ela tremia em meus braços, mas não aparentava estar machucada. As pessoas nos cercavam buscando saber como estávamos, eu estava bem, porém muito preocupado com o estado da Inaho.<br/>
- Inaho! Inaho! Tudo bem? Está machucada? Dói em algum lugar? Por favor, me responda!<br/>
Ela estava em estado de choque e chorando. Pouco depois uma ambulância chegou para nos socorrer. Ela estava bem, mas com o psicológico abalado. Já eu tinha machucado meu braço, mas nada grave. Depois do curativo feito fiquei a espera dela na enfermaria. Passado uns cinco minutos ela sai, mais recuperada e com feição mais calma. Pegamos nossas coisas e fomos embora.<br/>
- Como está o seu braço? - Ah não foi nada demais, só uns arranhões. A enfermeira falou que preciso trocar os curativos uma vez por dia e tomar cuidado com boladas e coisas do tipo. E você? - Eu estou um pouco melhor. O trauma não foi tão grande. (um momento de silêncio) Sabe eu poderia pensar que a culpa disso tudo poderia ser sua, mas prefiro pensar o contrário. Afinal se não fosse você eu ainda estaria ajoelhada no chão da escola chorando ou atropelada pela van, enfim, muito obrigada! Hoje você foi meu herói Takeyama-kun.<br/>
Palavras melhores não poderiam sair da boca dela naquele momento. Apesar de todos os acontecimentos as palavras ditas por ela me fizeram o cara mais feliz do mundo naquele instante.  Voltando para casa passamos por mais um semáforo e dessa vez me certifiquei que ela atravessasse a rua em segurança e ela riu quando fiz isso.<br/>
- Seu bobo, eu não vou repetir o mesmo erro de novo, ou pelo menos não por agora. (risos)<br/>

- Isso não é engraçado, se não tivesse alguém por perto você poderia ter morrido. Por favor, preste mais atenção a partir de agora. Não me dê mais sustos como esse. - Haha não fique todo convencido de suas ações herói-san, você não é meu pai e se vou tomar cuidado isso é comigo. Sinto muito por lhe preocupar. - Não, não entenda assim. Eu não quero me meter na sua vida. O que eu quero é o que qualquer pessoa desejaria ao próximo. - Tudo bem, então tomarei cuidado por causa de todas essas pessoas. - Por mim tudo bem. Eu vou virar aqui, minha casa é logo ali. Cuidado ao chegar em casa. Descanse bem e até amanhã.<br/> - Até amanhã.<br/></h5><div id="pagenum">Capítulo 1 – Rejeitado por quem amo. | 2 |</div> </div><div id="pages"><h5>
Enquanto me viro ela me chama a atenção:<br/>
- Takeyama-kun! Muito obrigada por hoje. Sua companhia me fez bem, mas isso não significa que somos amigos. Só agradeço por ter sido gentil comigo. <br/>Amanhã nós voltaremos a nossa antiga relação de colegas desconhecidos. - Tudo bem. Então se cuide! Tchau, tchau. - (em pensamento) Mesmo eu sendo rude com ele seu comportamento não mudou. Por que age assim Takeyama-kun?<br/>
Voltando para meu caminho dei as costas e andei em direção a minha casa. De certa forma fiquei magoado com o que ela disse, mas o que eu poderia esperar? Que ela me chamasse de amigo e quisesse dividir o almoço com ela amanhã? As coisas não acontecem assim, e eu também não conseguiria falar muito com ela. Então o que me restava era continuar como um "colega desconhecido". Mas pelo menos nossa caminhada rendeu uma breve conversa. Chegando em casa minha mãe se espantou com meu machucado e me pediu uma explicação. Sua reação foi surpreendente. Ela ficou brava, mas orgulhosa e também surpresa pelo que tinha feito. Então ela me mandou tomar banho, pois a janta estava quase pronta. Enquanto subia me encontrei com meu irmão, mais velho.<br/>
- Que ataduras são essas? Andou salvando uma garota de algum valentão?<br/>
No momento em que ele falou isso fiquei envergonhado e respondi:<br/>
- Aaah!! Isso não importa!  - (risos) Está na cara (Mais risos)<br/>
O ignorei e fui me preparar para o banho.<br/>


Depois do banho, ainda no banheiro, fui trocar minhas ataduras e enquanto as trocava me orgulhava do que tinha feito. Meu pai me ensinou que sempre deveríamos nos esforçar para ajudar alguém, ainda mais quando é alguém que amamos ( :3 ). E que todo esforço feito sempre é recompensado de alguma forma. Eu espero que Inaho-chan se lembre de mim de alguma forma, e espero que seja da forma mais positiva possível.  Meu pai é formado em fisioterapia e trabalha num tipo de clinica-laboratório responsável pela reabilitação de atletas, ex-atletas e pessoas que sofreram graves lesões. Ele é especializado em ampliar as condições físicas dos lesionados. Isso sempre me chamou atenção, pois seus esforços para ajudar essas pessoas sempre foram recompensados com elogios e reconhecimento, como, por exemplo, jogadores famosos de futebol já foram a essa clínica para tratar de suas lesões e ficaram muito agradecidos pelo trabalho do meu pai. Tenho muito orgulho dele e pretendo seguir o mesmo caminho.  Faço ajudando o técnico do time de futebol da escola com nossos integrantes e acho que estamos indo bem, afinal ganhamos a copa Inverno da nossa cidade. Já estamos nos preparando para o campeonato nacional e a copa de Verão. Por enquanto estamos estudando todas as possibilidades para os novos desafios desse ano. Temos o Genji como melhor jogador do time e eu como capitão, porém a partir de amanhã não sei se as coisas vão continuar assim. Acho melhor descer e esperar meu pai, afinal ele deve estar quase chegando.<br/>
Na cozinha encontro meu irmão lendo alguns papéis.<br/>
- Que papéis são esses irmão? <br/>- Você é curioso, não acha? <br/>- Anda logo e fala! <br/>- É uma proposta indireta de uma empresa de robótica de Tóquio. Eles têm uma pequena filial aqui na cidade que funciona como um projeto de campo.  <br/>- E o que você acha? Vai aceitar? <br/>- Estou analisando, mas é bem provável que sim. É na área que quero e me ofereceram um bom salário e ao depender do meu desempenho posso ser transferido para a Matriz em Tóquio.</h5><div id="pagenum">Capítulo 1 – Rejeitado por quem amo. | 3 |</div> </div><div id="pages"><h5> - Wow que legal! Estou torcendo por você irmão! <br/>- (risos) Obrigado Kaito, mas me conte como esse machucado foi parar aí.  <br/>- Éééé... Assim... Como eu falo. (falando rápido) Voltando com minha colega ela cruzou o farol vermelho dos pedestres sem prestar atenção e quase foi atropelada, foi aí que entrei na frente da van, agarrei minha colega, rolei pelo chão, mas vinha outro carro e não sei como consegui desviar para o outro lado (ofegante)...<br/>


- O QUÊÊÊÊ?! VOCÊ PULOU NAFRENTE DE UM CARRO PARA SALVAR UMA GAROTA? Qual seu problema? Você nunca foi de fazer loucuras como essa. Eu sabia que tinha mulher envolvida no caso, mas pelo menos acabou tudo bem. Vai contar pro pai? <br/> - Pretendo. Não tenho por que esconder algo do que me orgulhei - Realmente, do jeito que o papai é ele vai querer fazer uma festa pra você. <br/>- (sonhando)... <br/>- Ei acorda! <br/>- Quê?! Aah sim... Falando nele será que vai demorar? <br/>- Deve estar quase chegando. *porta se abre* Pai:<br/> - Cheguei! <br/>- Pai!<br/> - Ainda bem que chegou, eu estou morrendo de fome!<br/> Mãe: - Takashi não é assim que se fala com seu pai! Seja bem-vindo meu amor. Hoje você demorou mais do que de costume. O que aconteceu? Pai: - Tudo bem querida, hoje eu demorei mesmo, mas foi por um bom motivo. Durante o jantar eu comento o que aconteceu.<br/>
*pai olha a bandagem no meu braço*<br/>
- O que foi isso filho? <br/> - O quê? <br/> - Não me faça de besta! <br/>- Perdão pai! Pois então... (conta toda a história)<br/> - O QUÊ? VOCÊ FEZ ISSO? ARRISCOU SUA VIDA PRA SALVAR UMA GAROTA DESASTRADA? Você quase morreu meu filho, mesmo assim estou muito orgulhoso de você. Afinal arriscar sua vida pela vida de outra pessoa é incrível, imprudente, mas incrível. Pode ter certeza que esse feito lhe trará muitas recompensas, inclusive o amor dessa garota.(olhar de malícia) <br/>- (fica corado) Qu-qu-qu- quê?! <br/>- Claro, é óbvio que você não teria feito tudo isso se não gostasse dela.  - M-m-m-mas é claro que faria.<br/> - Filho você já se entregou. Eu sou seu pai, eu te conheço. Sei quando você tenta desviar a atenção. <br/> - Desisto - Não vai nem tentar?<br/> - Pra quê? É verdade! <br/>- Ok, ok. Vou tomar meu banho agora, podem comer na minha frente, vou demorar um pouco mais no banho.<br/>


- Aeew.<br/>
Takashi já sentado a mesa colocando o prato.<br/>
- Ei Aniki <sup>1</sup> isso não vale! - Tô morrendo de fome!<br/>
Depois de comer fui para o meu quarto estudar e planejar o treino de amanhã. Pouco tempo depois meu pai bate a porta e pergunta se posso conversar.
- Filho como está se sentindo? - Estou bem pai, um pouco irritado, mas estou bem. Que bom que o senhor veio aqui eu estava mesmo precisando conversar. - O que aconteceu? Algum problema na escola? - Mais ou menos. Hoje o Genji fez algo que me deixou com muita raiva. Sabe a garota que lhe falei mais cedo, a Inaho-san?  - Sim. - Ela gosta do Genji e se declarou hoje pra ele depois do treino.  - Isso deve ter magoado muito filho, mas o que aconteceu que levou a tudo isso? - O bom foi que o Genji a rejeitou, mas não uma rejeição qualquer, ele a humilhou totalmente. Quando vi aquilo tive que me conter para não partir pra cima dele.  - Que situação complicada, não imaginava que o Sakamoto-kun fosse assim. E então o que mais quer falar? - Se eu ver o Genji amanhã não sei como reagir, tenho medo de fazer besteira.  - Primeiro você tem de retirar esses sentimentos de você. Um homem não luta só com as mãos. Você tem muito potencial pra sair por aí brigando. Em primeira mão converse, fale como se sentiu depois do que ele fez, visto que ele é seu amigo fale pra ele a respeito dos seus sentimentos pela tal moça. Entende? - Talvez eu consiga pai, mas até amanhã vou me decidir. Agora vou terminar minhas atividades e dormir.  - Tudo bem Kaito, boa noite meu filho. - Boa noite pai, e de novo muito obrigado pelos conselhos. - Eu só cumpri minha obrigação como pai meu filho. (da um leve sorriso e fecha a porta)<br/>
                                  </h5>       <fieldset>    <a id="asteristico"> 1 Nota básica: (Aniki) é uma expressão utilizada para se referir ao irmão mais velho.</a><br/></fieldset><div id="pagenum">Capítulo 1 – Rejeitado por quem amo. | 4 |</div> </div><div id="pages"><h5>


    Depois dessa conversa terminei meus afazeres e fui dormir, mas na verdade fiquei pensando sobre o que deveria fazer amanhã ao encontrar Genji. Por mais que ele tenha feito aquilo eu ainda gosto muito da amizade dele e confesso não ter entendido a forma como ele agiu. Realmente a melhor coisa a fazer é compreender a situação. Na manhã seguinte enquanto subia a colina indo para a escola fui relembrando do que aconteceu no dia anterior. E acabei encontrando a razão dos meus pensamentos. Inaho-san estava parada esperando o sinal abrir, menos mal, respirei aliviado. Parei ao seu lado e cumpri o que disse ontem, a tratei como desconhecida. Enquanto esperava o sinal abrir ela me olhou discretamente, mas mantive a palavra. O sinal então abriu e segui caminho. De repente uma mão toca meu ombro.<br/>
- Takeyama-kun? Éééé... Bom dia (dizia a Inaho-san com um sorriso bem tímido e rosto corado) - Éééé... (Gaguejando)... Bom dia? - Vamos juntos hoje? Gostaria de conversar com você, serei breve. - Mas e quanto ao que disse ontem? - Vamos esquecer aquilo um pouco. - Por mim tudo bem então. Vamos.
Não podia acreditar no que estava vendo, a minha paixonite estava querendo conversar comigo. O que mais poderia acontecer? Aaaaa o amor! Enquanto fazíamos o percurso para e escola um silêncio agonizante tomava conta do ambiente. Eu estava muito inquieto com esse clima então tentei quebrá-lo, mas fui surpreendido.  Falamos ao mesmo tempo:<br/>
- Como você está?<br/>
Ambos ficamos envergonhados e respondemos ao mesmo tempo:<br/>
- Ah eu estou bem! - Tudo bem.<br/>
Depois voltamos a ficar em silêncio.<br/>
- (...)<br/>
Instantaneamente rimos de nossas ações deixando o clima mais suave. Decidi começar falando.<br/>


- Mais calma depois de ontem? - Sim, sim, e seu braço?  - Aah (levantando o braço) estamos ótimos. Eu sinceramente tenho muito orgulho desse ferimento, não foi nada grave, mas mesmo assim vou levar qualquer cicatriz que ficar como uma recompensa. - Não fale assim, ontem foi um dia traumático, por que você levaria uma ferida como algo valioso? - Simples. Ela é o símbolo de que pude ser útil para alguém. Afinal eu salvei uma vida. - Isso não seria egoísmo? - Não, não pense assim. Não quero méritos nem nada e só quero ter o sentimento de utilidade. - Entendo, é um pensamento nobre dependendo do ponto de vista. Parabéns. - (leve sorriso) Obrigado! Mas então, você queria me falar uma coisa. O que é?  - Aaah... Éééé... Eu queria lhe agradecer em primeiro lugar por ontem, mas não só por ter me salvo, mas também por ter ficado comigo depois do que aconteceu. Sua presença, por mais que fosse uma pessoa não tão próxima foi significativa pra mim. - (surpreso) Na verdade eu que te agradeço. - Por quê? - Por ter confiado em mim. - (sorriso tímido) Você é um cara legal Takeyama-kun. E sobre isso, eu (...) eu gostaria que você reconsiderasse aquilo que lhe falei sobre sermos amigos. Pode ser? - Eu fico muito agradecido pelo convite, mas acho melhor não.  - Não entendi, por quê? - Um dia você vai entender. Chegamos. Muito obrigado pela companhia, mas nos separamos por aqui, tenho algumas atividades na sala do clube. - Mas... É sério isso? Você está rejeitando minha amizade? - Não, não pense como rejeição. Mas não acho que sermos amigos agora será bom. - Pode me explicar o motivo?  - Só te peço paciência por enquanto. Você vai entender. - Eu não te entendo, mas tudo bem. Nos vemos por aí (bate a mão e sai) - (monólogo) Aaah o que eu fiz!!! Qual meu problema?! Tudo tão perto e tão fácil, mas espera... Fácil o caramba, eu quase morri ontem! Esquece.  - (monólogo da Inaho) Rejeitada dois dias seguidos. O que está acontecendo comigo.(raiva (também né))  </h5>
    <div id="pagenum">Capítulo 1 – Rejeitado por quem amo. | 5 |</div><h5>
    <fieldset id="nav" name="Navegação"><a href="cap2.php" id="nav">Cap #2 -></a> </fieldset>
</div>
<div id="footer">
    Ookami Enterprise <?php echo $ss; ?>
    <a href="http://nerdfakecompany.esy.es/nF_Studios/" id="logoInsider">Powered by nF Studios</a>
</div>
</body>
</html>